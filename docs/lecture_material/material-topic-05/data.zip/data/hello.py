PLANET = "Earth"


def hello_world():
    print(f"Hello {PLANET}!")
